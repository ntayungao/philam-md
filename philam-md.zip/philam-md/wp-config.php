<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'philam-md' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'FU8Vir8.6]MhCA78|v{:S1B2lG-%7I_6rY(Kdp=Qz,2  _$N97/WhPfJSM[jd=7n' );
define( 'SECURE_AUTH_KEY',  'dqa)#HkFTs/5p}cBKq.xWWB6s-u3a/ycs<RZBI;OSU_$:R&:vC0p8O?8Rt|Yga-<' );
define( 'LOGGED_IN_KEY',    '|&a0~6Cn<CMS[#)1rBh3QR8{FjdgNl)IMT-$ATpF>&XTV%Ofj wo8(oD{[u&VvXX' );
define( 'NONCE_KEY',        'dT Hs/?xeyr?X1hW[>8,$|?g%A^}n^m`aq++T4|ig,rsb.pwFL)^_fCItN;;aaOp' );
define( 'AUTH_SALT',        'Z$~JQtuN*#DO[YFO5 &uF|V2(THqJB-xmaF9=Z5|(2z]dH6cNZ4XVQ$q]@PCCri!' );
define( 'SECURE_AUTH_SALT', 'DoAQfLF_f;yNonsI0O`LoB*Z~=N@P9N?w9pzVcf{Y&[`i4d Hya!`d Nm)PwAsvi' );
define( 'LOGGED_IN_SALT',   'u#YVP1s%/:0:Q&l(RiD;07k)8<#oV3x~.r 4]Qya3xz]!bV=eaQ!WxPy&sx8hRUT' );
define( 'NONCE_SALT',       '9Uf9>&{YLcN$y/hW!(6najf+;,9WZHd.B$Q;c%f`5I%63p@7M1,9v864~l?wE>? ' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
